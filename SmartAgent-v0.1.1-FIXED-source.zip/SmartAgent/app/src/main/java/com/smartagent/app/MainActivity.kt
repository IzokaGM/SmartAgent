package com.smartagent.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.smartagent.app.data.ContentRequest
import com.smartagent.app.data.ContentStyle
import com.smartagent.app.data.GenerationRecord
import com.smartagent.app.data.GeminiClient
import com.smartagent.app.data.ImageUtils
import com.smartagent.app.data.InputMode
import com.smartagent.app.data.LocalRepository
import com.smartagent.app.data.OutputLanguage
import com.smartagent.app.data.Platform
import com.smartagent.app.data.PromptBuilder
import com.smartagent.app.data.SecureKeyStore
import com.smartagent.app.ui.theme.SmartAgentTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {
    private val incomingText = mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        readSharedText(intent)

        val secureKeyStore = SecureKeyStore(applicationContext)
        val repository = LocalRepository(applicationContext)
        val geminiClient = GeminiClient()

        setContent {
            SmartAgentTheme {
                SmartAgentApp(
                    incomingText = incomingText.value,
                    secureKeyStore = secureKeyStore,
                    repository = repository,
                    geminiClient = geminiClient
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readSharedText(intent)
    }

    private fun readSharedText(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            incomingText.value = intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
        }
    }
}

private enum class AppTab(val label: String, val symbol: String) {
    CREATE("Create", "✦"),
    HISTORY("History", "◷"),
    SETTINGS("Settings", "⚙")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SmartAgentApp(
    incomingText: String,
    secureKeyStore: SecureKeyStore,
    repository: LocalRepository,
    geminiClient: GeminiClient
) {
    var selectedTab by rememberSaveable { mutableStateOf(AppTab.CREATE) }
    var history by remember { mutableStateOf(repository.loadHistory()) }
    var keyConfigured by remember { mutableStateOf(secureKeyStore.hasApiKey()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("SmartAgent", fontWeight = FontWeight.Bold)
                        Text(
                            "Your private content assistant",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                AppTab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = { Text(tab.symbol) },
                        label = { Text(tab.label) }
                    )
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (selectedTab) {
                AppTab.CREATE -> CreateScreen(
                    incomingText = incomingText,
                    secureKeyStore = secureKeyStore,
                    repository = repository,
                    geminiClient = geminiClient,
                    keyConfigured = keyConfigured,
                    onOpenSettings = { selectedTab = AppTab.SETTINGS },
                    onRecordCreated = { record ->
                        history = repository.addHistory(record)
                    }
                )

                AppTab.HISTORY -> HistoryScreen(
                    records = history,
                    onClear = {
                        repository.clearHistory()
                        history = emptyList()
                    }
                )

                AppTab.SETTINGS -> SettingsScreen(
                    secureKeyStore = secureKeyStore,
                    repository = repository,
                    keyConfigured = keyConfigured,
                    onKeyStateChanged = { keyConfigured = it }
                )
            }
        }
    }
}

@Composable
private fun CreateScreen(
    incomingText: String,
    secureKeyStore: SecureKeyStore,
    repository: LocalRepository,
    geminiClient: GeminiClient,
    keyConfigured: Boolean,
    onOpenSettings: () -> Unit,
    onRecordCreated: (GenerationRecord) -> Unit
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    var mode by rememberSaveable { mutableStateOf(InputMode.AFFILIATE) }
    var productLink by rememberSaveable { mutableStateOf("") }
    var productName by rememberSaveable { mutableStateOf("") }
    var productFacts by rememberSaveable { mutableStateOf("") }
    var platform by rememberSaveable { mutableStateOf(Platform.TIKTOK) }
    var duration by rememberSaveable { mutableStateOf(30) }
    var language by rememberSaveable { mutableStateOf(OutputLanguage.MALAY) }
    var style by rememberSaveable { mutableStateOf(ContentStyle.UGC) }
    var audience by rememberSaveable { mutableStateOf("") }
    var imageBase64 by remember { mutableStateOf<String?>(null) }
    var imageStatus by rememberSaveable { mutableStateOf("No screenshot selected") }
    var isReadingImage by remember { mutableStateOf(false) }
    var isGenerating by remember { mutableStateOf(false) }
    var output by rememberSaveable { mutableStateOf("") }
    var errorMessage by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(incomingText) {
        if (incomingText.isNotBlank() && incomingText != productLink) {
            productLink = incomingText
            mode = InputMode.AFFILIATE
        }
    }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            isReadingImage = true
            imageStatus = "Reading screenshot..."
            scope.launch {
                runCatching {
                    withContext(Dispatchers.IO) {
                        ImageUtils.readAndCompress(context.contentResolver, uri)
                    }
                }.onSuccess {
                    imageBase64 = it
                    imageStatus = "Screenshot ready"
                }.onFailure {
                    imageBase64 = null
                    imageStatus = "Could not read screenshot"
                    errorMessage = it.message ?: "Could not read the screenshot"
                }
                isReadingImage = false
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Column(Modifier.padding(18.dp)) {
                    Text(
                        "From product to publish-ready content",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(6.dp))
                    Text("Share a link, add a screenshot, then generate your complete content pack.")
                }
            }
        }

        if (!keyConfigured) {
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Add your free Gemini API key before generating.", Modifier.weight(1f))
                        TextButton(onClick = onOpenSettings) { Text("Set up") }
                    }
                }
            }
        }

        item {
            SectionTitle("1. What are you creating?")
            ChoiceRow(
                options = InputMode.entries,
                selected = mode,
                label = { it.label },
                onSelected = { mode = it }
            )
        }

        if (mode == InputMode.AFFILIATE) {
            item {
                OutlinedTextField(
                    value = productLink,
                    onValueChange = { productLink = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Shopee or TikTok product link") },
                    placeholder = { Text("Paste or share a product link") },
                    minLines = 2
                )
            }
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { imagePicker.launch("image/*") },
                        enabled = !isReadingImage
                    ) {
                        Text(if (imageBase64 == null) "Add screenshot" else "Replace screenshot")
                    }
                    if (isReadingImage) CircularProgressIndicator(Modifier.width(22.dp))
                    Text(imageStatus, style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        item {
            OutlinedTextField(
                value = productName,
                onValueChange = { productName = it },
                modifier = Modifier.fillMaxWidth(),
                label = {
                    Text(if (mode == InputMode.AFFILIATE) "Product name" else "Topic or content idea")
                },
                singleLine = true
            )
        }

        item {
            OutlinedTextField(
                value = productFacts,
                onValueChange = { productFacts = it },
                modifier = Modifier.fillMaxWidth(),
                label = {
                    Text(if (mode == InputMode.AFFILIATE) "Verified product facts" else "Notes")
                },
                placeholder = {
                    Text("Features, price, material, size, promotion, or facts to include")
                },
                minLines = 4
            )
        }

        item {
            SectionTitle("2. Content settings")
            Text("Platform", style = MaterialTheme.typography.labelLarge)
            ChoiceRow(
                options = Platform.entries,
                selected = platform,
                label = { it.label },
                onSelected = { platform = it }
            )
            Spacer(Modifier.height(10.dp))
            Text("Duration", style = MaterialTheme.typography.labelLarge)
            ChoiceRow(
                options = listOf(10, 15, 30, 60, 120),
                selected = duration,
                label = { "${it}s" },
                onSelected = { duration = it }
            )
            Spacer(Modifier.height(10.dp))
            Text("Language", style = MaterialTheme.typography.labelLarge)
            ChoiceRow(
                options = OutputLanguage.entries,
                selected = language,
                label = { it.label },
                onSelected = { language = it }
            )
            Spacer(Modifier.height(10.dp))
            Text("Style", style = MaterialTheme.typography.labelLarge)
            ChoiceRow(
                options = ContentStyle.entries,
                selected = style,
                label = { it.label },
                onSelected = { style = it }
            )
        }

        item {
            OutlinedTextField(
                value = audience,
                onValueChange = { audience = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Target audience, optional") },
                placeholder = { Text("Example: Students, working mothers, new homeowners") },
                singleLine = true
            )
        }

        if (errorMessage.isNotBlank()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    )
                ) {
                    Text(
                        errorMessage,
                        modifier = Modifier.padding(14.dp),
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                }
            }
        }

        item {
            Button(
                onClick = {
                    errorMessage = ""
                    val key = secureKeyStore.loadApiKey()
                    when {
                        key == null -> {
                            errorMessage = "Add your Gemini API key in Settings first."
                            onOpenSettings()
                        }
                        productName.isBlank() && productFacts.isBlank() && imageBase64 == null -> {
                            errorMessage = "Add a product name, product facts, topic, or screenshot."
                        }
                        else -> {
                            val request = ContentRequest(
                                mode = mode,
                                productLink = productLink,
                                productName = productName,
                                productFacts = productFacts,
                                platform = platform,
                                durationSeconds = duration,
                                language = language,
                                style = style,
                                audience = audience,
                                hasScreenshot = imageBase64 != null
                            )
                            isGenerating = true
                            output = ""
                            scope.launch {
                                val response = withContext(Dispatchers.IO) {
                                    geminiClient.generate(
                                        apiKey = key,
                                        model = repository.loadModel(),
                                        prompt = PromptBuilder.build(request),
                                        imageBase64 = imageBase64
                                    )
                                }
                                response.onSuccess { generated ->
                                    output = generated
                                    val now = System.currentTimeMillis()
                                    onRecordCreated(
                                        GenerationRecord(
                                            id = now,
                                            createdAt = now,
                                            title = productName.ifBlank { "Untitled content" },
                                            platform = platform.label,
                                            result = generated
                                        )
                                    )
                                }.onFailure {
                                    errorMessage = it.message ?: "Content generation failed"
                                }
                                isGenerating = false
                            }
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                enabled = !isGenerating && !isReadingImage
            ) {
                if (isGenerating) {
                    CircularProgressIndicator(
                        modifier = Modifier.width(22.dp),
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                    Spacer(Modifier.width(10.dp))
                    Text("Creating content pack...")
                } else {
                    Text("Generate content pack")
                }
            }
        }

        if (output.isNotBlank()) {
            item {
                SectionTitle("Your content pack")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        clipboard.setText(AnnotatedString(output))
                    }) { Text("Copy all") }

                    OutlinedButton(onClick = {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, output)
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Share content pack"))
                    }) { Text("Share") }
                }
                Spacer(Modifier.height(10.dp))
                Card {
                    Text(
                        output,
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
    }
}

@Composable
private fun HistoryScreen(
    records: List<GenerationRecord>,
    onClear: () -> Unit
) {
    var selectedRecord by remember { mutableStateOf<GenerationRecord?>(null) }
    val clipboard = LocalClipboardManager.current

    if (selectedRecord != null) {
        val record = selectedRecord!!
        AlertDialog(
            onDismissRequest = { selectedRecord = null },
            title = { Text(record.title) },
            text = {
                Box(
                    Modifier
                        .height(420.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(record.result)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    clipboard.setText(AnnotatedString(record.result))
                }) { Text("Copy") }
            },
            dismissButton = {
                TextButton(onClick = { selectedRecord = null }) { Text("Close") }
            }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 28.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionTitle("Generation history")
                if (records.isNotEmpty()) {
                    TextButton(onClick = onClear) { Text("Clear") }
                }
            }
        }

        if (records.isEmpty()) {
            item {
                Card {
                    Column(Modifier.padding(20.dp)) {
                        Text("No content yet", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(5.dp))
                        Text("Your latest 50 content packs will be stored privately on this phone.")
                    }
                }
            }
        } else {
            items(records, key = { it.id }) { record ->
                Card(onClick = { selectedRecord = record }) {
                    Column(Modifier.padding(16.dp)) {
                        Text(record.title, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "${record.platform}  |  ${DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(record.createdAt))}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            record.result.take(150).replace('\n', ' '),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    secureKeyStore: SecureKeyStore,
    repository: LocalRepository,
    keyConfigured: Boolean,
    onKeyStateChanged: (Boolean) -> Unit
) {
    var apiKey by rememberSaveable { mutableStateOf("") }
    var model by rememberSaveable { mutableStateOf(repository.loadModel()) }
    var message by rememberSaveable { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SectionTitle("Private AI setup")
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer
            )
        ) {
            Column(Modifier.padding(16.dp)) {
                Text(
                    if (keyConfigured) "Gemini API key is configured" else "Gemini API key is not configured",
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(5.dp))
                Text("Your key is encrypted with Android Keystore and is not included in app backups.")
            }
        }

        OutlinedTextField(
            value = apiKey,
            onValueChange = { apiKey = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text(if (keyConfigured) "Replace Gemini API key" else "Gemini API key") },
            placeholder = { Text("Paste your key here") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            singleLine = true
        )

        OutlinedTextField(
            value = model,
            onValueChange = { model = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Gemini model") },
            supportingText = { Text("Default: ${LocalRepository.DEFAULT_MODEL}") },
            singleLine = true
        )

        Button(
            onClick = {
                runCatching {
                    if (apiKey.isNotBlank()) secureKeyStore.saveApiKey(apiKey)
                    repository.saveModel(model)
                }.onSuccess {
                    apiKey = ""
                    onKeyStateChanged(secureKeyStore.hasApiKey())
                    message = "Settings saved"
                }.onFailure {
                    message = it.message ?: "Could not save settings"
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = apiKey.isNotBlank() || keyConfigured
        ) {
            Text("Save settings")
        }

        if (keyConfigured) {
            OutlinedButton(
                onClick = {
                    secureKeyStore.clearApiKey()
                    onKeyStateChanged(false)
                    message = "API key removed"
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Remove API key")
            }
        }

        if (message.isNotBlank()) {
            Text(message, color = MaterialTheme.colorScheme.primary)
        }

        HorizontalDivider()
        Text("How to get a free key", fontWeight = FontWeight.Bold)
        Text(
            "Open Google AI Studio in your browser, create a Gemini API key, then paste it above. SmartAgent sends product information only when you tap Generate."
        )
        Text(
            "SmartAgent 0.1.1  |  Personal build",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
    )
}

@Composable
private fun <T> ChoiceRow(
    options: List<T>,
    selected: T,
    label: (T) -> String,
    onSelected: (T) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { option ->
            FilterChip(
                selected = selected == option,
                onClick = { onSelected(option) },
                label = { Text(label(option)) }
            )
        }
    }
}
