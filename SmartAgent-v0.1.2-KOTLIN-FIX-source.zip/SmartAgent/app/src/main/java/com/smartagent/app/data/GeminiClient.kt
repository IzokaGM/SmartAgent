package com.smartagent.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class GeminiClient {
    fun generate(
        apiKey: String,
        model: String,
        prompt: String,
        imageBase64: String? = null
    ): Result<String> = runCatching {
        val safeModel = model.trim().ifBlank { LocalRepository.DEFAULT_MODEL }
        val endpoint = URL(
            "https://generativelanguage.googleapis.com/v1beta/models/$safeModel:generateContent"
        )

        val parts = JSONArray().put(JSONObject().put("text", prompt))
        if (!imageBase64.isNullOrBlank()) {
            parts.put(
                JSONObject().put(
                    "inline_data",
                    JSONObject()
                        .put("mime_type", "image/jpeg")
                        .put("data", imageBase64)
                )
            )
        }

        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put("parts", parts)
                )
            )
            .put(
                "generationConfig",
                JSONObject()
                    .put("temperature", 0.75)
                    .put("maxOutputTokens", 4096)
            )

        val connection = (endpoint.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 30_000
            readTimeout = 90_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            setRequestProperty("x-goog-api-key", apiKey)
        }

        try {
            connection.outputStream.use { stream ->
                stream.write(body.toString().toByteArray(Charsets.UTF_8))
            }

            val statusCode = connection.responseCode
            val responseText = (if (statusCode in 200..299) {
                connection.inputStream
            } else {
                connection.errorStream
            })?.bufferedReader()?.use { it.readText() }.orEmpty()

            if (statusCode !in 200..299) {
                val message = runCatching {
                    JSONObject(responseText).getJSONObject("error").getString("message")
                }.getOrDefault("Gemini request failed with status $statusCode")
                error(message)
            }

            val candidates = JSONObject(responseText).optJSONArray("candidates")
                ?: error("Gemini returned no content")
            if (candidates.length() == 0) error("Gemini returned no candidates")

            val responseParts = candidates.getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")

            buildString {
                for (index in 0 until responseParts.length()) {
                    val text = responseParts.getJSONObject(index).optString("text")
                    if (text.isNotBlank()) append(text)
                }
            }.ifBlank { error("Gemini returned an empty response") }
        } finally {
            connection.disconnect()
        }
    }
}
