# SmartAgent

SmartAgent is a private Android content assistant for Malaysian creators. It converts a product, screenshot, or content idea into a publish-ready content pack for TikTok, Facebook, Threads, or WhatsApp.

## Current first release

- Affiliate and organic content modes
- Product link input through paste or Android Share
- Automatic product detail extraction using Gemini URL Context
- Shopee and TikTok short-link redirect resolution
- Product screenshot input with Gemini image understanding
- Bahasa Melayu Malaysia and British English output
- TikTok, Facebook, Threads, and WhatsApp formats
- 10, 15, 30, 60, and 120 second durations
- UGC, soft sell, storytelling, honest review, faceless, and problem solution styles
- Three hooks, a timed storyboard, full voice-over, caption, hashtags, pinned comment, and creator checklist
- Encrypted Gemini API key using Android Keystore
- Local history for the latest 50 generations
- Copy and Android Share actions
- Light and dark themes

## Privacy model

The app has no SmartAgent account, analytics, advertisement SDK, remote database, or payment system. The Gemini key is encrypted on the device and excluded from Android backups. Product information is sent to the selected Gemini model only after the user taps Generate.

## Build the APK with GitHub

1. Upload this project to a GitHub repository.
2. Open the repository's Actions tab.
3. Select **Build SmartAgent APK**.
4. Tap **Run workflow**.
5. When the build finishes, open it and download **SmartAgent-debug-apk** from Artifacts.
6. Extract the ZIP file and install `app-debug.apk` on the Android phone.

Android may ask for permission to install applications from the browser or file manager used to open the APK.

## Set up AI generation

1. Create a Gemini API key in [Google AI Studio](https://aistudio.google.com/app/apikey).
2. Open SmartAgent and select **Settings**.
3. Paste the key and tap **Save settings**.
4. Return to **Create** and generate a content pack.

The default model is `gemini-2.5-flash-lite`. It can be changed in Settings if Google changes model availability.

## Development configuration

- Android Gradle Plugin 8.13.0
- Gradle 8.13
- Kotlin 2.2.10
- Jetpack Compose BOM 2025.08.00
- Minimum Android version: Android 8.0, API 26
- Target Android version: API 36

The GitHub workflow builds the debug APK automatically. No Gemini API key is stored in the repository or required during the build.

## Planned next improvements

- Editable structured product preview before generation
- Section-level regeneration
- Saved brand voice profiles
- Separate caption, hook, and storyboard copy buttons
- Optional content calendar
