package com.smartagent.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class GeminiClient {
    fun generate(
        apiKey: String,
        model: String,
        prompt: String,
        imageBase64: String? = null,
        productUrl: String? = null
    ): Result<String> = runCatching {
        val parts = JSONArray().put(JSONObject().put("text", prompt))
        if (!imageBase64.isNullOrBlank()) {
            parts.put(
                JSONObject().put(
                    "inline_data",
                    JSONObject()
                        .put("mime_type", "image/jpeg")
                        .put("data", imageBase64)
                )
            )
        }

        val body = createBody(
            parts = parts,
            temperature = 0.75,
            maxOutputTokens = 4096,
            enableUrlContext = !productUrl.isNullOrBlank()
        )
        execute(apiKey, model, body).text
    }

    fun extractProduct(
        apiKey: String,
        model: String,
        productUrl: String
    ): Result<ProductDetails> = runCatching {
        val resolvedUrl = ProductLinkResolver.resolve(productUrl).getOrDefault(productUrl.trim())
        val prompt = """
            Read this public product page: $resolvedUrl

            Extract only facts that are explicitly shown on the page. Do not infer or invent anything.
            Return one JSON object only, without Markdown, using exactly this structure:
            {
              "name": "exact product name or empty string",
              "price": "price and currency or empty string",
              "description": "short factual description or empty string",
              "features": ["verified feature"],
              "seller": "seller or shop name if shown, otherwise empty string",
              "promotion": "promotion if shown, otherwise empty string",
              "warning": "what could not be verified, otherwise empty string"
            }
        """.trimIndent()

        val body = createBody(
            parts = JSONArray().put(JSONObject().put("text", prompt)),
            temperature = 0.1,
            maxOutputTokens = 1400,
            enableUrlContext = true
        )
        val response = execute(apiKey, model, body)
        if (!hasSuccessfulUrlRetrieval(response.candidate)) {
            error("The shop blocked automatic access. Add a product screenshot instead.")
        }

        val productJson = extractJsonObject(response.text)
        val name = productJson.optString("name").trim()
        val facts = buildFacts(productJson)
        if (name.isBlank() && facts.isBlank()) {
            error("No product details were visible on the page. Add a screenshot instead.")
        }

        ProductDetails(
            name = name,
            facts = facts,
            resolvedUrl = resolvedUrl,
            retrievalNote = productJson.optString("warning").trim()
        )
    }

    private fun createBody(
        parts: JSONArray,
        temperature: Double,
        maxOutputTokens: Int,
        enableUrlContext: Boolean
    ): JSONObject = JSONObject()
        .put(
            "contents",
            JSONArray().put(
                JSONObject()
                    .put("role", "user")
                    .put("parts", parts)
            )
        )
        .put(
            "generationConfig",
            JSONObject()
                .put("temperature", temperature)
                .put("maxOutputTokens", maxOutputTokens)
        )
        .apply {
            if (enableUrlContext) {
                put(
                    "tools",
                    JSONArray().put(JSONObject().put("url_context", JSONObject()))
                )
            }
        }

    private fun execute(apiKey: String, model: String, body: JSONObject): GeminiResponse {
        val safeModel = model.trim().ifBlank { LocalRepository.DEFAULT_MODEL }
        val endpoint = URL(
            "https://generativelanguage.googleapis.com/v1beta/models/$safeModel:generateContent"
        )
        val connection = (endpoint.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 30_000
            readTimeout = 90_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            setRequestProperty("x-goog-api-key", apiKey)
        }

        try {
            connection.outputStream.use { stream ->
                stream.write(body.toString().toByteArray(Charsets.UTF_8))
            }

            val statusCode = connection.responseCode
            val responseText = (if (statusCode in 200..299) {
                connection.inputStream
            } else {
                connection.errorStream
            })?.bufferedReader()?.use { it.readText() }.orEmpty()

            if (statusCode !in 200..299) {
                val message = runCatching {
                    JSONObject(responseText).getJSONObject("error").getString("message")
                }.getOrDefault("Gemini request failed with status $statusCode")
                error(message)
            }

            val candidates = JSONObject(responseText).optJSONArray("candidates")
                ?: error("Gemini returned no content")
            if (candidates.length() == 0) error("Gemini returned no candidates")

            val candidate = candidates.getJSONObject(0)
            val responseParts = candidate
                .getJSONObject("content")
                .getJSONArray("parts")
            val text = buildString {
                for (index in 0 until responseParts.length()) {
                    val partText = responseParts.getJSONObject(index).optString("text")
                    if (partText.isNotBlank()) append(partText)
                }
            }.ifBlank { error("Gemini returned an empty response") }

            return GeminiResponse(text = text, candidate = candidate)
        } finally {
            connection.disconnect()
        }
    }

    private fun hasSuccessfulUrlRetrieval(candidate: JSONObject): Boolean {
        val metadata = candidate.optJSONObject("urlContextMetadata")
            ?: candidate.optJSONObject("url_context_metadata")
            ?: return false
        val urls = metadata.optJSONArray("urlMetadata")
            ?: metadata.optJSONArray("url_metadata")
            ?: return false
        for (index in 0 until urls.length()) {
            val item = urls.optJSONObject(index) ?: continue
            val status = item.optString("urlRetrievalStatus")
                .ifBlank { item.optString("url_retrieval_status") }
            if (status.endsWith("SUCCESS")) return true
        }
        return false
    }

    private fun extractJsonObject(text: String): JSONObject {
        val first = text.indexOf('{')
        val last = text.lastIndexOf('}')
        if (first < 0 || last <= first) error("Product details could not be understood")
        return JSONObject(text.substring(first, last + 1))
    }

    private fun buildFacts(json: JSONObject): String = buildString {
        appendFact("Price", json.optString("price"))
        appendFact("Description", json.optString("description"))
        val features = json.optJSONArray("features")
        if (features != null && features.length() > 0) {
            append("Features:\n")
            for (index in 0 until features.length()) {
                val feature = features.optString(index).trim()
                if (feature.isNotBlank()) append("- ").append(feature).append('\n')
            }
        }
        appendFact("Seller", json.optString("seller"))
        appendFact("Promotion", json.optString("promotion"))
    }.trim()

    private fun StringBuilder.appendFact(label: String, value: String) {
        val clean = value.trim()
        if (clean.isNotBlank()) append(label).append(": ").append(clean).append('\n')
    }

    private data class GeminiResponse(
        val text: String,
        val candidate: JSONObject
    )
}
